This is based on Marcin Czachurski's dynamic wallpaper for MacOS:
https://itnext.io/macos-mojave-dynamic-wallpapers-ii-f8b1e55c82f

Images are from http:/himawari8.nict.go.jp/ and not allowed for commercial use. Credit for images goes to NASA.

JSON file is from Marcin Czachurski and adapted to KDE.

The set is distributed with permission from Marcin Czachurski and tested with dynamic-wallpaper-1.5.1 for KDE.
